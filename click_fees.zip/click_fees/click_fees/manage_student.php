<?php 
include 'db_connect.php'; 
if(isset($_GET['id'])){
$qry = $conn->query("SELECT * FROM student where id= ".$_GET['id']);
foreach($qry->fetch_array() as $k => $val){
    $$k=$val;
}
}
?>
<div class="container-fluid">
    <form action="" id="manage-student">
        <input type="hidden" name="id" value="<?php echo isset($id) ? $id : '' ?>">
        <div id="msg" class="form-group"></div>
        <div class="form-group">
        <?php if(isset($id_no) ): ?>
            <label for="" class="control-label " style="font-weight: 950;"><?php echo isset($id_no) ? $id_no :'' ?></label>
       
        <?php endif; ?>
           
            <input type="hidden" class="form-control" name="id_no"  value="<?php echo isset($id_no) ? $id_no :'0' ?>">
        </div>

    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="" class="control-label">Name</label>
            <input type="text" class="form-control" name="name"  value="<?php echo isset($name) ? $name :'' ?>" required>           
        </div>

        <div class="form-group col-md-6">
            <label for="" class="control-label">Father's Name</label>
            <input type="text" class="form-control" name="fathername"  value="<?php echo isset($fathername) ? $fathername :'' ?>" required>            
        </div>

    </div>



    <div class="form-row">
        <div class="form-group col-md-4">
			<label for="" class="control-label">Session</label>
			<select name="sessionid" id="sessionid" class="custom-select input-sm select2 ">
			    <option value=""></option>
				<?php
					$session = $conn->query("SELECT * FROM session order by 1");
					while($row= $session->fetch_assoc()):
				?>
				<option value="<?php echo $row['id'] ?>" <?php echo substr($row['name'],0,4) == date("Y") ? 'selected' : '' ?> ><?php echo $row['name'] ?></option>
				<?php endwhile; ?>
			</select>
        </div>

        <div class="form-group col-md-4">
            <label for="" class="control-label">Course</label>
			<select name="courseid" id="courseid" class="custom-select input-sm select2">
				<option value=""></option>
				<?php
					$session = $conn->query("SELECT * FROM courses order by 1");
					while($row= $session->fetch_assoc()):
				?>
				<option value="<?php echo $row['id'] ?>" <?php echo $row['id'] == $courseid ? 'selected' : '' ?>><?php echo ucwords($row['course'])?></option>
				<?php endwhile; ?>
			</select>
        </div>

        <div class="form-group col-md-4">
            <label for="" class="control-label">Branch</label>
			<select name="branchid" id="branchid" class="custom-select input-sm select2">
				<option value=""></option>
				<?php
					$session = $conn->query("SELECT * FROM branch order by 1");
					while($row= $session->fetch_assoc()):
				?>
				<option value="<?php echo $row['id'] ?>" <?php echo $row['id'] == $branchid ? 'selected' : '' ?>><?php echo ucwords($row['name'])?></option>
				<?php endwhile; ?>
			</select>
        </div>		
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">          
            <div class="form-check form-check-inline">        
                <input class="form-check-input" type="radio" name="coursetype" id="inlineRadio1" value="regular" <?php echo ($coursetype== 'regular') ?  "checked" : "" ;  ?>>
                <label class="form-check-label" for="inlineRadio1">Regular</label>        
            </div>
        </div>
        
        <div class="form-group col-md-4">
            <div class="form-check form-check-inline">        
                <input class="form-check-input" type="radio" name="coursetype" id="inlineRadio2" value="lateral" <?php echo ($coursetype== 'lateral') ?  "checked" : "" ;  ?>>
                <label class="form-check-label" for="inlineRadio2">Lateral Entry</label>
            </div>
        </div>
        
        <div class="form-group col-md-4">
            <div class="d-flex justify-content-center">
                <div class="form-check form-check-inline">
                <input  class="form-check-input" type="checkbox" id="feetype" name = "feetype" value="scholarship"
                 <?php if($feetype == 'scholarship') echo 'checked="checked"';?> >
                <label  class="form-check-label" for="feetype">SK</label>
            </div>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-6"> 
            <label for="" class="control-label">Contact</label>
            <input type="text" class="form-control" name="contact"  value="<?php echo isset($contact) ? $contact :'' ?>" required>
        </div>
        <div class="form-group col-md-6"> 
        <div class="form-group">
            <label for="" class="control-label">Email</label>
            <input type="email" class="form-control" name="email"  value="<?php echo isset($email) ? $email :'' ?>" required>
        </div>
    </div>
        
    <div class="form-group col-md-12"> 
            <label for="" class="control-label">Address</label>
            <textarea name="address" id="" cols="30" rows="3" class="form-control" required=""><?php echo isset($address) ? $address :'' ?></textarea>
        </div>
        
    </form>
</div>
<!--  Author Name: Vipul Saini 
 for any PHP, Angular, React OR Java work contact me at kvipul.saini@gmail.com   -->   
<script>
    $('#manage-student').on('reset',function(){
        $('#msg').html('')
        $('input:hidden').val('')
    })
    $('#manage-student').submit(function(e){
        e.preventDefault()
        start_load()
        $('#msg').html('')
        $.ajax({
            url:'ajax.php?action=save_student',
            data: new FormData($(this)[0]),
            cache: false,
            contentType: false,
            processData: false,
            method: 'POST',
            type: 'POST',
            success:function(resp){
            //   debugger;
                if(resp){
                    
                    alert_toast("Student successfully registerd."+resp,'success')
                        setTimeout(function(){
                            location.reload()
                        },2000)
                }else if(resp == 2){
                $('#msg').html('<div class="alert alert-danger mx-2">ID # already exist.</div>')
                end_load()
                }   
            }
        })
    })

    $('.select2').select2({
        placeholder:"Select here",
        width:'100%'
    })


</script>
<!--  Author Name: Vipul Saini 
 for any PHP, Angular, React OR Java work contact me at kvipul.saini@gmail.com   -->   